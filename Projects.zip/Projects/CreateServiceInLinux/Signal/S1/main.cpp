#include <signal.h>
#include <iostream>
#include <unistd.h>

using namespace std;

enum { MAXLINE = 1024 };
volatile sig_atomic_t eflag = 0;
char *info = NULL;

// Compliant Solution
void handler(int signum) {
    cout << "'SIGINT' Signal received." << endl;
    eflag = 1;
}

int main(void)
{
    int i = 0;
    if (signal(SIGINT, handler) == SIG_ERR) {
        /* Handle error */
    }
    info = (char *)malloc(MAXLINE);
    if (info == NULL) {
        /* Handle error */
    }

    while (!eflag) {
        cout << "Number is: " << i++ << endl;
        sleep(1);
    }

    free(info);
    info = NULL;
    cout << "Exiting..." << endl;

    return 0;
}

// Noncompliant Code
//void handler(int signum) {
//    cout << "'SIGINT' Signal received." << endl;
//    free(info);
//    info = NULL;
//}

//int main(void)
//{
//    int i = 0;
//    if (signal(SIGINT, handler) == SIG_ERR) {
//        /* Handle error */
//    }
//    info = (char *)malloc(MAXLINE);
//    if (info == NULL) {
//        /* Handle Error */
//    }

//    while (1) {
//        cout << "Number is: " << i++ << endl;
//        sleep(1);
//    }
//    return 0;
//}
