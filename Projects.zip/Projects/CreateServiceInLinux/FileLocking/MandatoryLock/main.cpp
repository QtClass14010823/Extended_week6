#include <sys/fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>

volatile int caught_signal = 0;

void handler(int sig)
{
    caught_signal = sig;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s file\n", argv[0]);
        exit(1);
    }

    signal(SIGCONT, handler);

    int fd = open(argv[1], O_RDWR);
    int ret;

    if (fd < 0) {
        /* Can't open lockfile */
        close(fd);
        exit(EXIT_FAILURE);
    }

    // set current position to byte 10
    if ((ret = lseek(fd, 10, SEEK_SET)) == -1) {
        close(fd);
        exit(EXIT_FAILURE);
    }

    // acquire exclusive lock for bytes in range [10; 15)
    // F_LOCK specifies blocking mode
    if ((ret = lockf(fd, F_LOCK, 5)) == -1) {
        close(fd);
        exit(EXIT_FAILURE);
    }

    // "kill -CONT [pid]" to resume
    pause();

    printf("Caught signal: %d, %s\n",
            caught_signal, strsignal(caught_signal));

    fprintf(stdout, "unlocking file...\n");

    // release lock for bytes in range [10; 15)
    if (lockf(fd, F_ULOCK, 5) == -1) {
        close(fd);
        exit(EXIT_FAILURE);
    }

    exit(0);
}

/*
#include <sys/fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "usage: %s file\n", argv[0]);
        exit(1);
    }

    int fd = open(argv[1], O_RDWR);
    if (fd == -1) {
        perror("open");
        exit(1);
    }

    struct flock fl = {};
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;

    if (fcntl(fd, F_SETLKW, &fl) == -1) {
        perror("fcntl");
        exit(1);
    }

    pause();
    exit(0);
}
*/

/*
    $mkdir dir
    $sudo mount -t tmpfs -o mand,size=1m tmpfs ./dir
    $echo hello > dir/lockfile
    $chmod g+s,g-x dir/lockfile
    $sudo umount dir

    or

    $mount -oremount,mand /
    $touch lockfile
    $chmod g+s,g-x lockfile
*/

// Acquire a lock in the first terminal:
/*
    $ ./locker dir/lockfile
    (wait for a while)
    ^C
*/


// Try to read the file in the second terminal:
/*
    $ cat dir/lockfile
    (hangs until ^C is pressed in the first terminal)
    hello
*/
