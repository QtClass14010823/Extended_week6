#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    if (argc > 1)
    {
        int fd = open(argv[1], O_WRONLY);
        int ret;

        if(fd == -1)
        {
            printf("Unable to open the file\n");
            exit(1);
        }

        // Test and lock a region for exclusive use.
        if ((ret = lockf(fd, F_TLOCK, 0)) == -1) {
            close(fd);
            exit(EXIT_FAILURE);
        }

        printf("Return value of fcntl:%d\n", ret);

        if(ret==0)
        {
            while (1)
            {
                scanf("%c", NULL);
            }
        }
    }

    exit(0);
}

/*
    $touch advisory.txt

    if bellow statement is running then lockf in new instance of program return -1
    else return 0

    $./AdvisoryLock advisory.txt
*/

/*
 * Note: Mandatory lock worked on regular partitions.
int main(int argc, char **argv)
{
    if (argc > 1)
    {
        int fd = open(argv[1], O_WRONLY);
        if(fd == -1)
        {
            printf("Unable to open the file\n");
            exit(1);
        }
        static struct flock lock;

        lock.l_type = F_WRLCK;
        lock.l_start = 0;
        lock.l_whence = SEEK_SET;
        lock.l_len = 0;
        lock.l_pid = getpid();

        int ret = fcntl(fd, F_SETLKW, &lock);
        printf("Return value of fcntl:%d\n", ret);
        if(ret==0)
        {
            while (1)
            {
                scanf("%c", NULL);
            }
        }
    }

    exit(0);
}
*/
