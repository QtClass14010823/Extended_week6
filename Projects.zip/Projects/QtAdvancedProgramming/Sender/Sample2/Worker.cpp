﻿#include "Worker.h"

#include <QDebug>
#include <QThread>
#include <QWidget>

Worker::Worker(QObject *parent) : QObject(parent)
{
}

void Worker::doWork(const bool isEven)
{
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        if (i % 2 == (isEven) ? 0 : 1)
            qDebug() << i;

        QObject *obj = QObject::sender();
        QWidget *widget = qobject_cast<QWidget *>(QObject::sender());

        QThread::sleep(1);
    }
}
