﻿#include <QCoreApplication>
#include <QSettings>

struct Login {
    QString userName;
    QString password;
};
QList<Login> logins {{"Ali", "123"}, {"Reza", "456"}, {"Mohammad", "789"}};

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSettings settings("Settings.ini", QSettings::IniFormat);

    settings.beginWriteArray("logins");
    for (int i = 0; i < logins.size(); ++i) {
        settings.setArrayIndex(i);
        settings.setValue("userName", logins.at(i).userName);
        settings.setValue("password", logins.at(i).password);
    }
    settings.endArray();

    logins.clear();

    int size = settings.beginReadArray("logins");
    for (int i = 0; i < size; ++i)
    {
        settings.setArrayIndex(i);
        Login login;
        login.userName = settings.value("userName").toString();
        login.password = settings.value("password").toString();
        logins.append(login);
    }
    settings.endArray();

    return 0; // a.exec()
}
