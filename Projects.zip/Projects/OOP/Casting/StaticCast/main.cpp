#include<iostream>

using namespace std;

int main()
{
    float f = 6.4;
    int i,j;
    i = f;      //implicit type conversion from float to int
    j = static_cast<int>(f);
    cout<<i<<"\n"<<j<<endl;
}
