int var = 0;
