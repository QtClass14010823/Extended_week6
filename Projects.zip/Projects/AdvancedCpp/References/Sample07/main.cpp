﻿#include <iostream>
using namespace std;

int& fun()
{
    static int x = 10;
    return x;
}

int main()
{
    fun() = 30;
    cout << fun() << endl;
    return 0;
}
