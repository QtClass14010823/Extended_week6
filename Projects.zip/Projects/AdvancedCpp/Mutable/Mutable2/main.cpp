#include <iostream>
#include <string.h>

using namespace std;

// Customer Class
class Customer {

    // class Variables
    string name;
    mutable int tel;

    // member methods
public:
    // constructor
    Customer(string s, int t)
    {
        name = s;
        tel = t;
    }

    // to change the place holder
    void changeTel(int t) const
    {
        tel = t;
    }

    // to display
    void display() const
    {
        cout << "Customer name is: " << name << endl;
        cout << "Customer tel is: " << tel << endl;
    }
};

// Driver code
int main()
{
    const Customer c1("Ali", 3);
    c1.display();
    c1.changeTel(5);
    c1.display();
    return 0;
}
